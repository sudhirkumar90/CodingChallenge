package com.zendesk.objectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.relevantcodes.extentreports.ExtentTest;
import com.zendesk.generic.Page;

public class TodosPage extends Page {

	public TodosPage(WebDriver driver, ExtentTest logger) {
		super(driver, logger);
	}

	// ***********************************************************//
	// ********************Page Elements*************************//
	// ***********************************************************//
	public Page TodoItemInput() {
		this.setElementName("TodoItem InputBox");
		this.setPath(By.id("new-todo"));
		return this;
	}

	public Page TodoItemDelete(String TodoItem) {
		this.setElementName("Delete button for TodoItem - " + TodoItem);
		this.setPath(By.xpath("//label[text()='" + TodoItem + "']/../button"));
		return this;
	}

	public Page TodoItemRow(String TodoItem) {
		this.setElementName("TodoItem - " + TodoItem);
		this.setPath(By.xpath("//label[text()='" + TodoItem + "']"));
		return this;
	}

	public Page UpdateTodoItemInput(String TodoItem) {
		this.setElementName(" TodoItem UpdateBox - " + TodoItem);
		this.setPath(By.xpath("//label[text()='" + TodoItem + "']/../../input[@class='edit']"));
		return this;
	}

	public Page CompleteTodoItemCheckbox(String TodoItem) {
		this.setElementName(" Complete TodoItem Input-Checkbox - " + TodoItem);
		this.setPath(By.xpath("//label[text()='" + TodoItem + "']/../input[@type='checkbox']"));
		return this;
	}

	public Page MainTodoItemRow(String TodoItem) {
		this.setElementName(" main TodoItem Row - " + TodoItem);
		this.setPath(By.xpath("//label[text()='" + TodoItem + "']/../.."));
		return this;
	}

	public Page CompleteAllButton() {
		this.setElementName("Complete All Button");
		this.setPath(By.id("toggle-all"));
		return this;
	}

	public Page CompleteTabLink() {
		this.setElementName("Complete Tab Link");
		this.setPath(By.id("ember339"));
		return this;
	}

	public Page ActiveTabLink() {
		this.setElementName("Active Tab Link");
		this.setPath(By.id("ember323"));
		return this;
	}

	public Page AllTabLink() {
		this.setElementName("All Tab Link");
		this.setPath(By.id("ember316"));
		return this;
	}

	public Page ClearCompletedButton() {
		this.setElementName("Clear Completed Button");
		this.setPath(By.id("clear-completed"));
		return this;
	}

	// ***********************************************************//
	// ********************Page Functions*************************//
	// ***********************************************************//

	public void addTodoItem(String TodoItem) {
		try {
			this.TodoItemInput().performSendkeysAndEnter(TodoItem);
			this.util.deadWait(1000);
			this.verificationUtil.assertElementExists(this.TodoItemRow(TodoItem));
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void completeTodoItem(String TodoItem) {
		try {
			this.CompleteTodoItemCheckbox(TodoItem).performClick();
			this.util.deadWait(300);
			this.verificationUtil.verifyElementAttribute(this.MainTodoItemRow(TodoItem), "class",
					"ember-view completed", TodoItem + " Completion");
			;
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void completeAllTodoItem(String TodoItems) {
		try {
			this.CompleteAllButton().performClick();
			this.util.deadWait(300);
			for (String item : TodoItems.split(","))
				this.verificationUtil.verifyElementAttribute(this.MainTodoItemRow(item), "class",
						"ember-view completed", item + " Completion");
			;
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void clearAllCompletedTodoItem(String TodoItems) {
		try {
			this.ClearCompletedButton().performClick();
			this.util.deadWait(300);
			for (String item : TodoItems.split(","))
				this.verificationUtil.assertElementDoesNotExists(this.TodoItemRow(item));

		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void checkTodosOnCompletedTab(String TodoItems) {
		try {
			this.CompleteTabLink().performClick();
			this.util.deadWait(300);
			for (String item : TodoItems.split(","))
				this.verificationUtil.verifyElementAttribute(this.MainTodoItemRow(item), "class",
						"ember-view completed", item + " Completion");
			;
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void checkTodosOnActiveTab(String TodoItem) {
		try {
			this.ActiveTabLink().performClick();
			this.util.deadWait(300);
			for (String item : TodoItem.split(","))
				this.verificationUtil.verifyElementAttribute(this.MainTodoItemRow(item), "class", "ember-view",
						item + " Active");
			;
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void reactivateTodoItem(String TodoItem) {
		try {
			this.CompleteTodoItemCheckbox(TodoItem).performClick();
			this.util.deadWait(500);
			this.verificationUtil.verifyElementAttribute(this.MainTodoItemRow(TodoItem), "class", "ember-view",
					TodoItem + " Reactivation");
			;
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void updateTodoItem(String TodoItem, String UpdatedTodoItem) {
		try {
			this.TodoItemRow(TodoItem).PerformDoubleClickOnElement();

			this.UpdateTodoItemInput(TodoItem).performSendkeysAndEnter(UpdatedTodoItem);
			this.verificationUtil.assertElementExists(this.TodoItemRow(UpdatedTodoItem));
		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}

	public void deleteTodos(String TodoItemToDelete) {
		try {
			this.AllTabLink().performClick();

			if (this.driver instanceof SafariDriver) {
				this.TodoItemDelete(TodoItemToDelete).performJavascriptClick();
			} else {
				this.TodoItemRow(TodoItemToDelete).PerformHoverOnElement();
				this.TodoItemDelete(TodoItemToDelete).performClick();
			}

			this.verificationUtil.assertElementDoesNotExists(this.TodoItemRow(TodoItemToDelete));

		} catch (Exception e) {
			this.verificationUtil.reportExceptionAndTakeScreenshot(driver, logger, e);
			throw e;
		}
	}
}
