package com.zendesk.generic;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Page {
	private String elementName;
	private By path;
	protected WebDriver driver;
	WebDriverWait wait;
	CustomReporting testNgLog;
	ExtentReports extent;
	protected ExtentTest logger;
	protected Verification verificationUtil;
	protected Utility util;

	public Page(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		wait = new WebDriverWait(this.driver, 30);
		this.logger = logger;
		verificationUtil = new Verification();
		util = new Utility(driver);
	}

	public Page(String elementName, By path) {
		this.setElementName(elementName);
		this.path = path;
	}

	public By getPath() {
		return path;
	}

	public void setPath(By path) {
		this.path = path;
	}

	public String getElementName() {
		return elementName;
	}

	public void waitForVisiblitityOfElement() {
		this.wait.until(ExpectedConditions.visibilityOfElementLocated(this.path));
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	public WebElement getElement() {
		this.waitForVisiblitityOfElement();
		return this.driver.findElement(this.path);
	}

	public List<WebElement> getAllMatchingElement() {
		return this.driver.findElements(this.path);
	}

	public void performClick() {
		logger.log(LogStatus.INFO, "Clicking on : " + this.getElementName());
		this.getElement().click();
	}
	
	public void performJavascriptClick() {
		logger.log(LogStatus.INFO, "Clicking on : " + this.getElementName());
		//JavascriptExecutor js = (JavascriptExecutor)driver;
       // js.executeScript("arguments[0].click();", this.getElement()); 
		//this.JSClick(this.getElement());
		
		WebElement element = this.driver.findElement(this.getPath());
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", element); 
	}

	public void performSendkeysAndEnter(String value) {
		logger.log(LogStatus.INFO, "Typing '" + value + "' on : " + this.getElementName());

		WebElement element = this.getElement();
		element.clear();
		element.sendKeys(value);
		this.util.deadWait(200);
		element.sendKeys(Keys.ENTER);
		logger.log(LogStatus.INFO, "Pressing Enter button on : " + this.getElementName());
	}

	public void performSendkeysAndTab(String value) {
		logger.log(LogStatus.INFO, "Typing '" + value + "' on : " + this.getElementName());

		WebElement element = this.getElement();
		element.clear();
		element.sendKeys(value);
		this.util.deadWait(200);
		element.click();
		element.sendKeys(Keys.TAB);
		logger.log(LogStatus.INFO, "Pressing Tab button on : " + this.getElementName());
	}

	public void PerformHoverOnElement() {
		logger.log(LogStatus.INFO, "Focusing on : " + this.getElementName());
		Actions builder = new Actions(driver);
		builder.moveToElement(this.getElement()).perform();
	}


	public boolean onDblClick(WebElement element) {
		boolean result = false;
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('dblclick',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(mouseOverScript, element);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}
	
	
	
	public boolean JSClick(WebElement element) {
		boolean result = false;
		try {
			String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('click',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject){ arguments[0].fireEvent('onmouseover');}";
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript(mouseOverScript, element);
			result = true;
		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}
		return result;
	}

	public void PerformDoubleClickOnElement() {
		logger.log(LogStatus.INFO, "Double click on : " + this.getElementName());
		

		this.onDblClick(this.getElement());
	}

	public void performClear() {
		logger.log(LogStatus.INFO, "Clearing value of : " + this.getElementName());
		this.getElement().clear();
	}

	public String getELementText() {
		return this.getElement().getText();
	}

	public void refereshPage() {
		this.driver.navigate().refresh();
	}

	public void performSelect(String text) {
		logger.log(LogStatus.INFO, "Selecting '" + text + "' on : " + this.getElementName());

		Select select = new Select(this.getElement());
		select.selectByVisibleText(text);
	}

	public boolean checkIfElementPresent() {
		this.waitForVisiblitityOfElement();
		if (this.driver.findElements(this.path).size() > 0)
			return true;
		else
			return false;
	}

	// public void performPaginationCheck(List staffNames,Page nextButton) {
	// for (Object object : staffNames) {
	// if (this.checkNameInPage(object.toString(),nextButton))
	// logger.log(LogStatus.PASS, "Staff Name '" + object.toString() + "'
	// succesfully displayed.");
	// else {
	// logger.log(LogStatus.FAIL, "Staff Name '" + object.toString() + "' NOT
	// displayed.");
	//
	// }
	// }
	//
	// }

	// private boolean checkNameInPage(String staffName,Page nextButton) {
	// boolean flag = false;
	// String firstElement = this.getAllMatchingElement().get(0).getText();
	// String nextPageFirstElement="";
	// while (flag == false && !firstElement.equals(nextPageFirstElement)) {
	// for (WebElement element : this.getAllMatchingElement()) {
	// if (element.getText().contains(staffName))
	// return true;
	// }
	// nextButton.getElement().click();
	// new Utility().deadWait(2);
	// nextPageFirstElement=this.getAllMatchingElement().get(0).getText();
	// }
	//
	// return false;
	// }

}
