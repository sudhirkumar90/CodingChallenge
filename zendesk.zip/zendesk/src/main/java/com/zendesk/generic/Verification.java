package com.zendesk.generic;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Verification {

	public void verifyElementExists(Page element) {

		if (element.driver.findElements(element.getPath()).size() > 0) {
			element.logger.log(LogStatus.PASS, "'" + element.getElementName() + "' successfully displayed.");
			this.reportPassAndTakeScreenshot(element);
		}

		else {
			element.logger.log(LogStatus.FAIL, "'" + element.getElementName() + "' NOT displayed.");
			this.reportFailAndTakeScreenshot(element);
		}

	}
	
	public boolean verifyElementExistsBoolean(Page element) {

		if (element.driver.findElements(element.getPath()).size() > 0) {
			element.logger.log(LogStatus.PASS, "'" + element.getElementName() + "' successfully displayed.");
			this.reportPassAndTakeScreenshot(element);
			return true;
		}

		else {
			return false;
		}

	}

	public void assertElementExists(Page element) {

		if (element.driver.findElements(element.getPath()).size() > 0) {
			element.logger.log(LogStatus.PASS, "'" + element.getElementName() + "' successfully displayed.");
			this.reportPassAndTakeScreenshot(element);
			Assert.assertTrue(true, "'" + element.getElementName() + "' successfully displayed.");
		}

		else {
			element.logger.log(LogStatus.FAIL, "'" + element.getElementName() + "' NOT displayed.");
			this.reportFailAndTakeScreenshot(element);
			Assert.assertTrue(false, "'" + element.getElementName() + "' NOT displayed.");
		}

	}

	public void assertElementDoesNotExists(Page element) {

		if (element.driver.findElements(element.getPath()).size() > 0) {
			element.logger.log(LogStatus.FAIL, "'" + element.getElementName() + "' NOT removed.");
			this.reportFailAndTakeScreenshot(element);
			Assert.assertTrue(false, "'" + element.getElementName() + "' NOT removed.");
		}

		else {
			element.logger.log(LogStatus.PASS, "'" + element.getElementName() + "'successfully removed.");
			this.reportPassAndTakeScreenshot(element);
			Assert.assertTrue(true, "'" + element.getElementName() + "' successfully removed.");
		}

	}

	public void verifyText(Page element, String message) {
		if (element.getElement().getText().contains(message)) {
			element.logger.log(LogStatus.PASS, "'" + message + "' successfully displayed.");
			this.reportPassAndTakeScreenshot(element);
		} else {
			element.logger.log(LogStatus.FAIL,
					"'" + message + "' NOT displayed. Actual Message displayed is : " + element.getElement().getText());
			this.reportFailAndTakeScreenshot(element);
			Assert.assertTrue(true, "'" + element.getElementName() + "' NOT displayed.");
		}
	}
	
	public void verifyElementAttribute(Page element,String attribute, String expected,String Message) {
			String actual=element.getElement().getAttribute(attribute);
		if (actual.contains(expected)) {
			element.logger.log(LogStatus.PASS, "'" + expected + "' successfully displayed. "+Message+" successfull !");
			this.reportPassAndTakeScreenshot(element);
		} else {
			element.logger.log(LogStatus.FAIL,
					"'" + expected + "' NOT displayed. Actual value displayed is : " + actual+". "+Message+" NOT successfull !");
			this.reportFailAndTakeScreenshot(element);
			Assert.assertTrue(true, "'" + expected + "' NOT displayed. Actual result :"+actual+". "+Message+" NOT successfull !");
		}
	}

	public void reportPassAndTakeScreenshot(Page element) {

		element.logger.log(LogStatus.PASS,
				"Snapshot below: " + element.logger.addScreenCapture(new Utility(element.driver).getScreenshot()));
	}

	public void reportFailAndTakeScreenshot(Page element) {

		element.logger.log(LogStatus.FAIL,
				"Snapshot below: " + element.logger.addScreenCapture(new Utility(element.driver).getScreenshot()));
	}

	public void reportExceptionAndTakeScreenshot(WebDriver driver, ExtentTest logger, Exception e) {

		logger.log(LogStatus.FAIL, "Snapshot below: " + logger.addScreenCapture(new Utility(driver).getScreenshot()));
		logger.log(LogStatus.FAIL, e.getCause());

	}
	
	public void reportFailAndLogMessage(ExtentTest logger, Exception e) {
		logger.log(LogStatus.FAIL, e.getCause());

	}

}
