package com.zendesk.generic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ConfigProperties {
	Properties prop = new Properties();

	public ConfigProperties() {
		try {
			prop.load(new FileInputStream(
					System.getProperty("user.dir") + "/src/main/java/com/zendesk/config/config.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getProperty(String propertyName) {
		return this.prop.getProperty(propertyName);
	}
}
