package com.zendesk.generic;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class CustomReporting {
	public ExtentReports extent;
	public ExtentTest logger;

	CustomReporting(){
		
	}
	public CustomReporting(String testName, String description) {
		extent = new ExtentReports(System.getProperty("user.dir") + "/"
				+ (new ConfigProperties().getProperty("ReportFolder")) + "/"+(new ConfigProperties().getProperty("ReportName")) +".html",false);
		logger = extent.startTest(testName, description);
	}

	public void clearOldData() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/"
				+ (new ConfigProperties().getProperty("ReportFolder")) + "/"+(new ConfigProperties().getProperty("ReportName")) +".html", true);
		this.generateReport();
	}

	public void generateReport() {
		extent.endTest(logger);
		extent.flush();

	}

}
