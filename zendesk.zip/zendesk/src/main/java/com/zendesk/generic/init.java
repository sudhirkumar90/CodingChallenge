package com.zendesk.generic;

import org.testng.annotations.BeforeSuite;

public class init {

	
	@BeforeSuite
	public void BeforeSuite(){
		System.out.println("****Executing Before Test*****");
		
		if((new ConfigProperties()).getProperty("AppendReport").contains("true")){
			System.out.println("****clearing reports*****");

		CustomReporting report=new CustomReporting();
		report.clearOldData();
		}
		
	}
	
}
