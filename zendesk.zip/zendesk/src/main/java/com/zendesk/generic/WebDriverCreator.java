package com.zendesk.generic;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

public class WebDriverCreator {

	WebDriver driver;

	Properties prop;

	public WebDriverCreator() {
		
		this.CreateDriver(new ConfigProperties().getProperty("BrowserName"));
		this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public WebDriver getDriver() {
		return this.driver;
	}

	public void CreateDriver(String browserName) {

		switch (browserName) {
		case "Firefox":
			//System.setProperty("webdriver.gecko.driver",
			//		System.getProperty("user.dir") + "/resources/BrowserDriver/geckodriver");
			this.driver = new FirefoxDriver();
			break;
		case "Chrome":
			System.out.println(System.getProperty("os.name"));
			if(System.getProperty("os.name").contains("Mac"))
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "/resources/BrowserDriver/chromedriver");
			else
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "/resources/BrowserDriver/chromedriver.exe");
			this.driver = new ChromeDriver();
			break;
		case "Safari":
			DesiredCapabilities desiredCapabilities = DesiredCapabilities.safari();
			SafariOptions safariOptions = new SafariOptions();
			safariOptions.setUseCleanSession(true);
			desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
			this.driver = new SafariDriver(desiredCapabilities);
			break;
		default:
			System.out.println("Invalid Browser Name : " + browserName);
			break;

		}
	}

}
