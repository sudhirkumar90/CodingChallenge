package com.zendesk.generic;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Utility {

	WebDriver driver;

	public Utility(WebDriver driver) {
		this.driver = driver;
	}

	public Utility() {
	}

	public void deadWait(int miliseconds) {
		try {
			Thread.sleep(miliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String getScreenshot() {
		String uniqueFolder = (new Date()).toString();
		long uniqueSS = (new Date()).getTime();
		String reportpath = System.getProperty("user.dir") + "/" + (new ConfigProperties().getProperty("ReportFolder"))
				+ "/" + (new ConfigProperties().getProperty("ScreenshotFolder")) + "/" + uniqueFolder + "/ss" + uniqueSS
				+ ".png";
		String path = (new ConfigProperties().getProperty("ScreenshotFolder")) + "/" + uniqueFolder + "/ss"
				+ uniqueSS + ".png";
		File scrFile = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(reportpath));
		} catch (IOException e) {
			e.printStackTrace();
		}

		return path;
	}

	public String getRandomString() {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 5) {
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		return saltStr;
	}

}
