package com.zendesk.testcases;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.zendesk.generic.ConfigProperties;
import com.zendesk.generic.CustomReporting;
import com.zendesk.generic.ExcelUtils;
import com.zendesk.generic.Utility;
import com.zendesk.generic.Verification;
import com.zendesk.generic.WebDriverCreator;
import com.zendesk.objectRepository.TodosPage;

public class TodosTC {
	WebDriver driver;
	CustomReporting reporter;
	Utility util;

	@BeforeMethod(alwaysRun = true)
	public void beforeTest() throws FileNotFoundException, IOException {
		try {
			driver = new WebDriverCreator().getDriver();
			driver.get(new ConfigProperties().getProperty("url"));
			util = new Utility(driver);
		} catch (Exception e) {
			new Verification().reportFailAndLogMessage(reporter.logger, e);
			throw e;
		}
	}

	// ***********************************************************//
	// ********************Data Provides*************************//
	// ***********************************************************//
	@DataProvider(name = "AddAndDeleteTodoItem")
	public Object[][] getAddAndDeleteTodoItem() throws Exception {
		return (new ExcelUtils().getTableArray("AddAndDeleteTodoItem"));
	}

	@DataProvider(name = "AddEditDeleteTodoItem")
	public Object[][] getAddEditDeleteTodoItem() throws Exception {
		return (new ExcelUtils().getTableArray("AddEditDeleteTodoItem"));
	}

	@DataProvider(name = "AddCompleteDeleteTodoItem")
	public Object[][] getAddCompleteDeleteTodoItem() throws Exception {
		return (new ExcelUtils().getTableArray("AddCompleteDeleteTodoItem"));
	}

	@DataProvider(name = "AddCompleteReactivateDelete")
	public Object[][] getAddCompleteReactivateDeleteTodoItem() throws Exception {
		return (new ExcelUtils().getTableArray("AddCompleteReactivateDelete"));
	}

	@DataProvider(name = "AddCompleteAllDeleteAll")
	public Object[][] getAddCompleteAllDeleteAll() throws Exception {
		return (new ExcelUtils().getTableArray("AddCompleteAllDeleteAll"));
	}

	@DataProvider(name = "CheckActiveAndCompleted")
	public Object[][] getCheckActiveAndCompleted() throws Exception {
		return (new ExcelUtils().getTableArray("CheckActiveAndCompleted"));
	}

	// ***********************************************************//
	// **************************Tests ***************************//
	// ***********************************************************//
	@Test(testName="Todos : Add and Delete",dataProvider = "AddAndDeleteTodoItem", enabled = true)
	public void AddDeleteTodoItemTC(String TodoItem) {
		reporter = new CustomReporting("Todos : Add and Delete",
				"To validate the Addition and Deletion of a TodoItem.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		for (String item : TodoItem.split(","))
			todospg.addTodoItem(item.trim());

		for (String item : TodoItem.split(","))
			todospg.deleteTodos(item.trim());
	}

	@Test(testName="Todos : Add, Update and Delete",dataProvider = "AddEditDeleteTodoItem", enabled = true)
	public void AddEditDeleteTodoItemTC(String TodoItem, String UpdatedTodoItem) {
		reporter = new CustomReporting("Todos : Add, Update and Delete",
				"To validate the Addition, Updation and Deletion of a TodoItem.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		todospg.addTodoItem(TodoItem);
		todospg.updateTodoItem(TodoItem, UpdatedTodoItem);
		todospg.deleteTodos(UpdatedTodoItem);
	}

	@Test(testName="Todos : Add, Complete and Delete",dataProvider = "AddCompleteDeleteTodoItem", enabled = true)
	public void AddCompleteDeleteTodoItemTC(String TodoItem) {
		reporter = new CustomReporting("Todos : Add, Complete and Delete",
				"To validate the Addition, Completion and Deletion of a TodoItem.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		todospg.addTodoItem(TodoItem);
		todospg.completeTodoItem(TodoItem);
		todospg.deleteTodos(TodoItem);
	}

	@Test(testName="Todos : Add, Complete, Reactivate and Delete",dataProvider = "AddCompleteReactivateDelete", enabled = true)
	public void AddCompleteReactivateDeleteTC(String TodoItem) {
		reporter = new CustomReporting("Todos : Add, Complete, Reactivate and Delete",
				"To validate the Addition, Completion, Reactivate and Deletion of a TodoItem.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		todospg.addTodoItem(TodoItem);
		todospg.completeTodoItem(TodoItem);
		todospg.reactivateTodoItem(TodoItem);
		todospg.deleteTodos(TodoItem);
	}

	@Test(testName="Todos : Add, Complete-All and Delete-All",dataProvider = "AddCompleteAllDeleteAll", enabled = true)
	public void AddCompleteAllDeleteTC(String TodoItems) {
		reporter = new CustomReporting("Todos : Add, Complete-All and Delete-All",
				"To validate the Addition, Completing all task together and Deletion of All TodoItems.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		for (String item : TodoItems.split(","))
			todospg.addTodoItem(item.trim());

		todospg.completeAllTodoItem(TodoItems);
		todospg.clearAllCompletedTodoItem(TodoItems);

	}

	@Test(testName="Todos : CheckActiveAndCompletedTab", dataProvider = "CheckActiveAndCompleted", enabled = true)
	public void CheckActiveAndCompletedTabTC(String CompletedTodoItems, String ActiveTodoItems) {
		reporter = new CustomReporting("Todos : CheckActiveAndCompletedTab",
				"To validate the if the Active and Completed Todos are shown in their respective tabs.");
		TodosPage todospg = new TodosPage(driver, reporter.logger);
		for (String item : CompletedTodoItems.split(","))
			todospg.addTodoItem(item.trim());
		todospg.completeAllTodoItem(CompletedTodoItems);

		for (String item : ActiveTodoItems.split(","))
			todospg.addTodoItem(item.trim());

		todospg.checkTodosOnCompletedTab(CompletedTodoItems);
		todospg.checkTodosOnActiveTab(ActiveTodoItems);

		for (String item : CompletedTodoItems.split(","))
			todospg.deleteTodos(item.trim());
		for (String item : ActiveTodoItems.split(","))
			todospg.deleteTodos(item.trim());
	}

	@AfterMethod()
	public void aftermethod() {

		try {
			this.driver.quit();
		} catch (Exception e) {
			new Verification().reportExceptionAndTakeScreenshot(driver, reporter.logger, e);
			throw e;
		}

		this.reporter.generateReport();
	}
}
